# doppel

Personality-driven chatbot widget. Drop into any React app to represent a real person on your site.

This is the widget package. The companion .NET API lives at [`packages/api/Doppel.Api/`](../api/Doppel.Api/) and serves the `/chat` endpoint the widget talks to.

## Status

v0.1 shipped (repo v0.2.0). Package name: `@manucompiles/doppel` (scoped). See [`docs/plans/_archive/P3-doppel-widget-v0-1.md`](../../docs/plans/_archive/P3-doppel-widget-v0-1.md).

## Install

```sh
# Post-publish (npm publish is tracked in #4):
npm install @manucompiles/doppel

# Pre-publish: install the packed tarball or consume via the monorepo workspace alias.
# See examples/landing-page/ for a working integration.
```

## Quick start

```tsx
import { Doppel } from '@manucompiles/doppel';

export default function App() {
  return (
    <>
      <YourSiteContent />
      <Doppel persona="manu" apiEndpoint="http://localhost:5001" />
    </>
  );
}
```

That mounts the widget with the built-in `manu` persona and the default `warm-beach` theme, talking to a Doppel API running on `localhost:5000`.

## Props

| Prop | Type | Required | Description |
|---|---|---|---|
| `persona` | `PersonaPresetName \| PersonaConfig` | yes | Visual character + identity. Either a preset name string or a custom config object. |
| `theme` | `ThemePresetName \| PartialTheme` | no | Token overrides. Either a preset name or a partial object deep-merged over `warm-beach`. Defaults to `warm-beach` when omitted. |
| `apiEndpoint` | `string` | yes | URL of the self-hosted Doppel API. The widget POSTs to `${apiEndpoint}/chat`. |

## Four usage shapes

### 1. Built-in persona + built-in theme

```tsx
<Doppel persona="manu" theme="warm-beach" apiEndpoint="http://localhost:5000" />
```

### 2. Built-in persona + partial theme override

```tsx
<Doppel
  persona="manu"
  theme={{ colors: { primary: '#1E3A5F' } }}  // override one token, inherit the rest from warm-beach
  apiEndpoint="http://localhost:5000"
/>
```

### 3. Custom persona + built-in theme

```tsx
<Doppel
  persona={{
    name: 'Sarah',
    greeting: "Hey! I'm Sarah's digital self. What's your name?",
    tone: 'warm, technical, curious',
    owner: 'Sarah Example',
    role: 'Product designer',
  }}
  theme="cool-tech"
  apiEndpoint="https://your-doppel-api.com"
/>
```

### 4. Fully custom persona + fully custom theme

```tsx
<Doppel
  persona={{ name: 'Sarah', greeting: '...', tone: '...', owner: '...', role: '...' }}
  theme={{
    colors: { primary: '#FF6B35', surface: '#FFF8F0' },
    fonts: { body: '"My Site Font", system-ui, sans-serif' },
  }}
  apiEndpoint="https://your-doppel-api.com"
/>
```

## Theming via consumer CSS

Every Doppel token is also exposed as a CSS custom property on `.doppel-root`. You can override them from your own stylesheet without touching the React props:

```css
.doppel-root {
  --doppel-color-primary: #1E3A5F;
  --doppel-font-body: 'My Site Font', sans-serif;
}
```

Full token catalog: [`UI-SPEC.md`](../../UI-SPEC.md) at the repo root.

## Scripts

| Command | What it does |
|---|---|
| `npm run build` | Build the ESM library + type declarations to `dist/` |
| `npm run dev` | Build in watch mode (useful while iterating on the example app) |
| `npm test` | Run the Vitest suite once |
| `npm run test:watch` | Run Vitest in watch mode |
| `npm run typecheck` | Type-check `src/` against `tsconfig.build.json` (no emit) |

## Persona presets

v0.1 ships `manu` filled with placeholder SVG assets. The other three preset names (`office-guy`, `ship-captain`, `robo`) exist as folders with TODO markers - passing them to `<Doppel />` in v0.1 throws a descriptive error. They get content in v0.2.

Each persona is a folder under `src/personas/<name>/`:

- `idle.png` (or `.svg`) - lying-on-beach-chair pose
- `hover-1.png` ... `hover-N.png` - wave frames cycled on hover (CSS frame-cycling, 300ms cadence)
- `active.png` - standing-beside-chat pose
- `persona.ts` - default `PersonaConfig` (name, greeting, tone, owner, role)

### Asset creation path

Two paths for producing real avatars:

1. **Bitmoji web app** (bitmoji.com) - five-minute setup, free, looks like the persona owner. Snap's terms restrict commercial use; fine for a personal portfolio. Export each pose as a PNG, drop into the persona folder.
2. **AI-generated, Bitmoji-inspired** - take a Bitmoji export as reference, prompt Claude / ChatGPT / Midjourney to generate inspired-not-copied versions. Avoids the licensing concern at the cost of consistency work between poses.

v0.1 ships clearly-fake placeholder SVGs (labeled IDLE / WAVE 1-3 / ACTIVE) so widget development is not blocked on real avatar production.

## Theme presets

Three themes ship in v0.1:

| Preset | Vibe | Best for |
|---|---|---|
| `warm-beach` (default) | Warm amber + cream + sky | Portfolio sites, friendly tone |
| `cool-tech` | Slate + blue + emerald | Developer portfolios, engineering blogs |
| `minimal-clean` | Zinc + neutral + blue accent | Minimalist personal sites, designer portfolios |

All three define the same token shape (colors, fonts, spacing, radii, shadows, animation). Spacing, radii, and animation are theme-invariant per [`UI-SPEC.md`](../../UI-SPEC.md); only colors and fonts vary between presets.

## Accessibility

v0.1 accessibility commitments (verified via tests + manual review):

- Keyboard: Enter / Space opens the avatar, Escape closes the panel
- Focus indicators: 2px solid outline using `--doppel-color-primary` on all interactive elements
- Touch targets: minimum 44x44px on avatar, send button, close button, input
- ARIA: `role="dialog"` on panel, `role="log"` + `aria-live="polite"` on the message list, `aria-label` on every icon-only button
- Contrast: all token combinations across the three themes meet WCAG AA (4.5:1)
- Honors `prefers-reduced-motion`: no wave animation, no slide-in, instant state swaps

Full UX rule checklist: [`UI-SPEC.md`](../../UI-SPEC.md#ux-rules).
